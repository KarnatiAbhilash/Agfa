﻿public class ReportDocument
{
}